/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogIn;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.Random;
import java.util.ResourceBundle;

/**
 *
 * @author phant
 */
public class Ebank {

    private ResourceBundle rb;
    public Locale locale;
    public final String valid_accountNum = "[0-9]{10}";
    public final String valid_passwordNum = "((?=.*\\d)(?=.*[a-zA-Z])\\S{8,31})";
//            "^((?=.*\\d)(?=.*[a-zA-Z])\\S{8,31})$";
//            "^([a-zA-Z0-9!.#$@_+,?-])\\S{8,31}$";

    public Ebank() {
    }

    Ebank(ResourceBundle rb) {
        this.rb = rb;
    }

    void setLocale(Locale locale) {
        rb = ResourceBundle.getBundle("Language/" + locale);
    }

    public String checkAccount(String account) {
        //Check account người dùng nhập, trả về valid nếu hợp lệ và ngược lại
        if (account.matches(valid_accountNum)) {
            return null;
        } else {
            return rb.getString("wrongAccount");
        }

    }

    public String checkPassword(String pass) {

        if (pass.matches(valid_passwordNum)) {
            return null;
        } else {
            return rb.getString("wrongPassword");
        }

    }

    public String randomCaptcha() {
        Random rd = new Random();
        String alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int length = alphabet.length();
        String result = "";
        for (int i = 0; i < 5; i++) {
            int index = rd.nextInt(length);
            result += alphabet.charAt(index);
        }
        return result;
    }

    public String checkCaptcha(String capt, String inputCapt) {

        if (capt.contains(inputCapt) && !inputCapt.isEmpty()) {
            return null;
        } else {
            return rb.getString("wrongCaptcha");
        }

    }


}
