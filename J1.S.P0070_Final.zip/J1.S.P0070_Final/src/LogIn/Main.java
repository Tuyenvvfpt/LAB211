/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogIn;

import java.io.IOException;
import java.util.Locale;

/**
 *
 * 
 * @author phant
 */
public class Main {

//    static Ebank m = new Ebank();

    public static void main(String[] args) throws IOException {

        Manager c = new Manager();
        // Tạo đối tượng Ebank duy nhất
        Ebank ebank = new Ebank();

        while (true) {
            c.menu();
            int choice = c.inputChoice();
            switch (choice) {
                case 1:

                    c.changeLanguage(1);
                    break;
                case 2:
                    c.changeLanguage(2);                 
                    break;
                case 3:
                    return;
            }
            c.login();
        }
    }

  
}
