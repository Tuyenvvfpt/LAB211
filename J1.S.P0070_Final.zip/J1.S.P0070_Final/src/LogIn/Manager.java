/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogIn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.Random;
import java.util.ResourceBundle;
import jdk.vm.ci.meta.Local;

/**
 *
 * @author phant
 */
public class Manager {

    private Locale locate;
    private ResourceBundle rb;

    Ebank eBank = new Ebank(rb);

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    static int inputChoice() {
        int num;
        while (true) {
            try {
                System.out.print("Enter your decision: ");
                num = Integer.parseInt(in.readLine());
                if (num >= 1 && num <= 3) {
                    return num;
                } else {
                    System.out.println("Error! Your input must in the interval [1,3]");
                }
            } catch (Exception e) {
                System.out.println("Invalid input! Your input must be a number");
            }
        }
    }

    public void menu() {
        System.out.println("-------Login Program-------");
        System.out.println("1. Vietnamese");
        System.out.println("2. English");
        System.out.println("3. Exit");
        System.out.println();
    }

    void getLanguage(String str, ResourceBundle resource) {
        if (str != "account" && str != "password" && str != "captchaInput") {
            System.out.println(resource.getString(str));
        } else {
            System.out.print(resource.getString(str));
        }
    }


    void changeLanguage(int choice) {
        if (choice == 1) {
            locate = new Locale("vi");
            eBank.setLocale(locate);
            this.rb = ResourceBundle.getBundle("Language/" + locate);
        } else if (choice == 2) {
            locate = new Locale("en");
            eBank.setLocale(locate);
            this.rb = ResourceBundle.getBundle("Language/" + locate);
        }
    }

    void login() throws IOException {
        inputAccount();
        inputPassword();
        inputCaptcha();

    }

    private String inputAccount() throws IOException {
        while (true) {
            System.out.print(rb.getString("account"));
            String acc = in.readLine();
            String checkAcc = eBank.checkAccount(acc);
            if (checkAcc == null && !acc.isEmpty()) {
                return acc;
            } else {
                System.out.println(checkAcc);

            }
        }

    }

    private String inputPassword() throws IOException {
        while (true) {
            System.out.print(rb.getString("password"));
            String pass = in.readLine();
            String checkPass = eBank.checkPassword(pass);
            if (checkPass == null && !pass.isEmpty()) {
                return pass;
            } else {
                System.out.println(checkPass);
            }
        }
    }

    private String inputCaptcha() throws IOException {
        String inputCaptcha;

        while (true) {
            String capt = eBank.randomCaptcha();
            String login = rb.getString("logIn");
            System.out.println("Captcha: " + capt);
            System.out.print(rb.getString("captchaInput"));
//            String checkCapt = eBank.checkCaptcha(String capt, String inputCapt);
            inputCaptcha = in.readLine();

            if (eBank.checkCaptcha(capt, inputCaptcha) == null && !inputCaptcha.isEmpty()) {
                System.out.println(login);
                return inputCaptcha;
            } else {
                System.out.println(eBank.checkCaptcha(capt,inputCaptcha));
            }
        }

    }

}
